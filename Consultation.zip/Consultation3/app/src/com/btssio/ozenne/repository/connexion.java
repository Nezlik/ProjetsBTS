package com.btssio.ozenne.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
public class connexion {
	
	public List<String> getDomaine(){
		List<String> domaine = new ArrayList<>();
		Connection conn = null;
        try {
        	conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/bd_consultation?useSSL=false&useLegacyDatetimeCode=false","root","");
        	Statement stmt1 = conn.createStatement();
	        String requeteSQL = "select * from domaine";
	        ResultSet res;
	        res = stmt1.executeQuery(requeteSQL);
	        while (res.next()) {
	        	domaine.add(res.getString(0));
	        	domaine.add(res.getString(1));
	        }
	        stmt1.close();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        finally {
            try {
                if (conn!=null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return domaine;
	}
	 public static void main(String... args){
	        Connection conn = null;
	        try {
	                        
	            //MySQL driver MySQL Connector
	            conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/bd_consultation?useSSL=false&useLegacyDatetimeCode=false","root","");

	            //Oracle Driver officiel OJDBC Thin
	            //conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:vanille","root","");
	            //Postgres Driver officiel
	            //conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/vanille","root","");
	            System.out.println("success");
		        Statement stmt1 = conn.createStatement();
		        String requeteSQL = "select * from client";
		        ResultSet res;
		        res = stmt1.executeQuery(requeteSQL);
		        while (res.next()) {
		        	System.out.print(res.getString(1)+" ");
		        	System.out.println(res.getString(2));
		        	}
		        stmt1.close();
		        }
	        catch (SQLException e) {
	            e.printStackTrace();
	        }
	        finally {
	            try {
	                if (conn!=null) {
	                    conn.close();
	                }
	            } catch (SQLException e) {
	                e.printStackTrace();
	            }
	        }
	    }
}
