package com.btssio.ozenne.consultation.View

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import com.btssio.ozenne.consultation.Controller.MainController
import com.btssio.ozenne.consultation.Model.FormationsRepository
import com.btssio.ozenne.consultation.R
import java.lang.Exception


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //init des variables
        var formationsRepository = FormationsRepository(this)
        val spinFormations = findViewById<Spinner>(R.id.spinFormations)
        val spinDomaine = findViewById<Spinner>(R.id.spinDomaine)
        val txtDate = findViewById<TextView>(R.id.txtDate)

        //remplissage du spinner domaines
        spinDomaine.adapter = MainController.setDomaines(formationsRepository, this@MainActivity)

        //affichage formations en fonctions des domaines
        val spinDomaineListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                val selectedItem = parent?.getItemAtPosition(position).toString()
                try {
                    spinFormations.adapter = MainController.setFormationsParDomaine(
                        selectedItem,
                        formationsRepository,
                        this@MainActivity
                    )
                } catch (e: Exception) {
                    e.printStackTrace()
                    Toast.makeText(
                        this@MainActivity,
                        "Une erreur s'est produite : ${e.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }

        //affichage sessions en fonctions des formations
        val spinFormationsListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                val selectedItem = parent?.getItemAtPosition(position).toString()
                try {
                    txtDate.text =
                        MainController.setSessionParFormations(selectedItem, formationsRepository)
                } catch (e: Exception) {
                    e.printStackTrace()
                    Toast.makeText(
                        this@MainActivity,
                        "Une erreur s'est produite : ${e.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }
        //Assignation des listeners
        spinDomaine.onItemSelectedListener = spinDomaineListener
        spinFormations.onItemSelectedListener = spinFormationsListener
    }
}