package com.btssio.ozenne.consultation.Model

import android.content.Context
import android.util.Log
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.IOException

class FormationsRepository(private val context: Context) {
    var forma: List<Formations> = ArrayList()

    init {
        forma = recupererFormationsDepuisJson()
    }

    fun getDomaines(): List<String> {
        return forma
            .map { it.domaine }
            .distinct()
    }

    fun getFormationsUniques(prefix: String): List<String> {
        return forma
            .filter { it.domaine.startsWith(prefix) }
            .map { it.formations }
            .distinct()
    }

    fun getDateParFormation(prefix: String): List<String> {
        return forma
            .filter { it.formations.startsWith(prefix) }
            .map { it.session }
    }

    //Fonction pour charger la liste depuis le fichier json
    private fun recupererFormationsDepuisJson(): List<Formations> {

        val jsonFileString = getJsonDataFromAsset(context, "formations.json")
        if (jsonFileString == null) {
            Log.e("FormationsRepository", "JSON data is null")
            return emptyList()
        }
        val gson = Gson()
        val listeFormations = object : TypeToken<List<Formations>>() {}.type
        val formations =
            gson.fromJson<List<Formations>>(jsonFileString, listeFormations) ?: emptyList()

        // Convertir les noms de fichiers en identifiants de ressources
        return formations

    }


    private fun getJsonDataFromAsset(context: Context, fileName: String): String? {
        return try {
            context.assets.open(fileName).bufferedReader().use { it.readText() }
        } catch (ioException: IOException) {
            Log.e("FormationsRepository", "Error reading from $fileName", ioException)
            null
        }
    }
}
