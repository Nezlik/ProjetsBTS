package com.btssio.ozenne.consultation.Model

data class Formations(
    val id: String,
    val domaine: String,
    val formations: String,
    val session: String
)