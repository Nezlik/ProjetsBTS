package com.btssio.ozenne.consultation.Controller

import android.R
import android.content.Context
import android.widget.ArrayAdapter
import com.btssio.ozenne.consultation.Model.FormationsRepository

object MainController {
    fun setSessionParFormations(
        selectedItem: String,
        formationsRepository: FormationsRepository
    ): String {
        var session = ""

        try {
            if (selectedItem == "java") {
                val sessionUniquesParformations = formationsRepository.getDateParFormation("java")
                val sessionsAvecPhrase = sessionUniquesParformations.map { "Prochaine session : $it" }
                session = sessionsAvecPhrase.joinToString("\n\n")
            } else if (selectedItem == "adobe") {
                val sessionUniquesParformations = formationsRepository.getDateParFormation("adobe")
                val sessionsAvecPhrase = sessionUniquesParformations.map { "Prochaine session : $it" }
                session = sessionsAvecPhrase.joinToString("\n\n")
            } else if (selectedItem == "Cassoulet") {
                val sessionUniquesParformations =
                    formationsRepository.getDateParFormation("Cassoulet")
                val sessionsAvecPhrase = sessionUniquesParformations.map { "Prochaine session : $it" }
                session = sessionsAvecPhrase.joinToString("\n\n")
            }
            else if (selectedItem == "C#") {
                val sessionUniquesParformations =
                    formationsRepository.getDateParFormation("C#")
                val sessionsAvecPhrase = sessionUniquesParformations.map { "Prochaine session : $it" }
                session = sessionsAvecPhrase.joinToString("\n\n")
            }
            else if (selectedItem == "Risotto") {
                val sessionUniquesParformations =
                    formationsRepository.getDateParFormation("Risotto")
                val sessionsAvecPhrase = sessionUniquesParformations.map { "Prochaine session : $it" }
                session = sessionsAvecPhrase.joinToString("\n\n")
            }
            else if (selectedItem == "Tarte flambée") {
                val sessionUniquesParformations =
                    formationsRepository.getDateParFormation("Tarte flambée")
                val sessionsAvecPhrase = sessionUniquesParformations.map { "Prochaine session : $it" }
                session = sessionsAvecPhrase.joinToString("\n\n")
            }
            else if (selectedItem == "Débutant") {
                val sessionUniquesParformations =
                    formationsRepository.getDateParFormation("Débutant")
                val sessionsAvecPhrase = sessionUniquesParformations.map { "Prochaine session : $it" }
                session = sessionsAvecPhrase.joinToString("\n\n")
            }
            else if (selectedItem == "Avancé") {
                val sessionUniquesParformations =
                    formationsRepository.getDateParFormation("Avancé")
                val sessionsAvecPhrase = sessionUniquesParformations.map { "Prochaine session : $it" }
                session = sessionsAvecPhrase.joinToString("\n\n")
            }
            else if (selectedItem == "Expert") {
                val sessionUniquesParformations =
                    formationsRepository.getDateParFormation("Expert")
                val sessionsAvecPhrase = sessionUniquesParformations.map { "Prochaine session : $it" }
                session = sessionsAvecPhrase.joinToString("\n\n")
            }
        } catch (e: Exception) {
        }
        return session
    }

    fun setFormationsParDomaine(
        selectedItem: String,
        formationsRepository: FormationsRepository,
        context: Context
    ): ArrayAdapter<String> {
        val formationsUniquesParDomaine =
            if (selectedItem == "Informatique") {
                formationsRepository.getFormationsUniques("Informatique")
            }
            else if(selectedItem =="Cuisine") {
                formationsRepository.getFormationsUniques("Cuisine")
            }
            else{
                formationsRepository.getFormationsUniques("Communications")
            }
        return spinnerAdapter(context, formationsUniquesParDomaine)
    }

    fun spinnerAdapter(context: Context, items: List<String>): ArrayAdapter<String> {
        return ArrayAdapter(context, R.layout.simple_spinner_dropdown_item, items)
    }

    fun setDomaines(
        formationsRepository: FormationsRepository,
        context: Context
    ): ArrayAdapter<String> {
        return spinnerAdapter(context, formationsRepository.getDomaines())
    }
}
